//
//  AddItemViewController.swift
//  TodoList
//
//  Created by ASHLEY TRAN on 11/15/17.
//  Copyright © 2017 ASHLEY TRAN. All rights reserved.
//

import UIKit

class AddItemViewController: UIViewController {

    @IBOutlet weak var titleLabel: UITextField!
    
    @IBOutlet weak var descArea: UITextView!
    
    @IBOutlet weak var date: UIDatePicker!
    
    
    weak var delegate: AddItemDelegate?
    
    @IBAction func addButtonPressed(_ sender: UIButton) {
        let title = titleLabel.text!
        let desc = descArea.text!
        let d = date.date
        
        if title != "" && desc != ""{
            delegate?.addItem(title, desc, d, sender: self)
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        descArea.layer.borderWidth = 1
        descArea.layer.borderColor = UIColor.lightGray.cgColor
        descArea.layer.cornerRadius = 5
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
