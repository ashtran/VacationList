//
//  todoCell.swift
//  TodoList
//
//  Created by ASHLEY TRAN on 11/14/17.
//  Copyright © 2017 ASHLEY TRAN. All rights reserved.
//

import UIKit

class todoCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var descLabel: UITextView!
    

}
